package com.nagarro.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nagarro.dao.BookDao;
import com.nagarro.dto.DtoInput;
import com.nagarro.model.Book;


@Controller
public class BookController {

	@RequestMapping(path ="/SearchBook", method = RequestMethod.POST)
	public ModelAndView Search(@ModelAttribute DtoInput dt) {
		System.out.println(dt);
		List<Book> result = BookDao.SearchBook(dt);
		if (result.isEmpty()) {
			System.out.println("No books Available");
		}
		ModelAndView andView = new ModelAndView();
		andView.addObject("result", result);
		return andView;
	}

}

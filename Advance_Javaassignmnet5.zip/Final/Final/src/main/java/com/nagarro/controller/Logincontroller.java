package com.nagarro.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.nagarro.csvreader.ReadCsvData;
import com.nagarro.dao.LoginDao;
import com.nagarro.model.User;

@Controller
public class Logincontroller {

	@RequestMapping("login")
	public String login() {
		return "login";
	}

	@RequestMapping(path = "/login", method = RequestMethod.POST)
	public String Loginform(@ModelAttribute User user, Model model, @RequestParam("username") String username,
			@RequestParam("password") String password) {
		System.out.println(user);
		ReadCsvData.readFromCSV();
		if (LoginDao.validateUser(username, password) == true) {
			return "home1";
		}

		return "login";
	}

}

package com.nagarro.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nagarro.dto.DtoInput;
import com.nagarro.model.Book;
import com.nagarro.session.HibernateUtil;

public class BookDao {

	public static List<Book> SearchBook(DtoInput input) {
		Transaction tx = null;
		Session session = HibernateUtil.getSessionFactory().openSession();
		tx = session.beginTransaction();

		StringBuilder sb = new StringBuilder(
				"from Tshirt where name = :name and date = :date ");

		if (input.getCode() == 1) {
			sb.append(" order by price ");
		} else if (input.getCode() == 2) {
			sb.append(" order by rating DESC");
		} else {
			sb.append(" order by price ASC , rating DESC");
		}
		@SuppressWarnings("rawtypes")
		Query query = session.createQuery(sb.toString());
		query.setParameter("name", input.getName());
		query.setParameter("date", input.getDate());
		
		List<Book> sortedresult = query.list();
		tx.commit();
		session.close();

		return sortedresult;
	}
}

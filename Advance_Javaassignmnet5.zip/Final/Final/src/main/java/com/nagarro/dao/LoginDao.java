package com.nagarro.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nagarro.model.User;
import com.nagarro.session.HibernateUtil;

public class LoginDao {

	public static Boolean validateUser(String username, String password) {
		Transaction tx = null;
		Session session = HibernateUtil.getSessionFactory().openSession();
		tx = session.beginTransaction();
		String queryString = "From User where username =:username and password =:password";
		Query query = session.createQuery(queryString);
		query.setParameter("username", username);
		query.setParameter("password", password);
		@SuppressWarnings("unchecked")
		List<User> users = query.list();
		tx.commit();
		session.close();
		if (users.isEmpty()) {
			return false;
		}
		return true;

	}

}

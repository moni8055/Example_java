package com.nagarro.dto;

public class DtoInput {
	
	private String date;
	private String name;
	private int Code;

	
	public DtoInput(String date, String name, int code) {
		this.date = date;
		this.name = name;
		this.Code = code;
	}

	public DtoInput() {

	}

	@Override
	public String toString() {
		return "DtoInput [date=" + date + ", name=" + name + ",  code="
				+ Code + "]";
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCode() {
		return Code;
	}

	public void setCode(int code) {
		Code = code;
	}

}

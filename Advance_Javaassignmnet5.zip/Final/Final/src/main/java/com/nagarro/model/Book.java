package com.nagarro.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Book {
	@Id
	
	private String name;
	private String date;
	private Double code;
	
	public Book(String name, String date,  Double code) {
		super();
		
		this.name = name;
		this.date = date;
		this.code = code;
	}

	public Book() {

	}

	@Override
	public String toString() {
		return "Book [name=" + name + ", date=" + date + ", code=" + code + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Double getCode() {
		return code;
	}

	public void setCode(Double code) {
		this.code = code;
	}

	

}
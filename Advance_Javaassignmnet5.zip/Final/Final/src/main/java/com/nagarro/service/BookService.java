package com.nagarro.csvreader;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.nagarro.model.Book;

public class BookService{

public List<Book> getAllBooks() {
    RestTemplate restTemplate = new RestTemplate();
    String url = "http://localhost:8081/books";
    ResponseEntity<Book[]> responseEntity = restTemplate.getForEntity(url, Book[].class);
    Book[] books = responseEntity.getBody();
    return Arrays.asList(books);
}
}

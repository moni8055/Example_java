package com.nagarro.training.csv_assignment.controller;

import java.util.ArrayList;

import com.nagarro.training.csv_assignment.domain.TShirt;
import com.nagarro.training.csv_assignment.dto.TShirtSearchDTO;
import com.nagarro.training.csv_assignment.service.TShirtMatchingService;
import com.nagarro.training.csv_assignment.view.Input;
import com.nagarro.training.csv_assignment.view.Output;


public class Application {
	public static void main(String[] args) {
		
		//take input
		Input input=new Input();
		TShirtSearchDTO tShirtSearchDTO = input.getDetails();
		
		
		//generate result
		TShirtMatchingService tShirtMatchingService = new TShirtMatchingService();
		ArrayList<TShirt> matchingTshirts = tShirtMatchingService.getMatchingTshirts(tShirtSearchDTO);
		
		//display output
		Output output = new Output();
	    output.displayDetails(matchingTshirts);
		
		
		
		
		
		
	}
}

package com.nagarro.training.csv_assignment.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

import com.nagarro.training.csv_assignment.domain.TShirt;
import com.nagarro.training.csv_assignment.dto.TShirtSearchDTO;
import com.nagarro.training.csv_assignment.view.Output;

public class TShirtMatchingService<Product> {

	public ArrayList<TShirt> getMatchingTshirts(TShirtSearchDTO tShirtSearchDTO) {
		ArrayList<TShirt> allTShirts = null;
		ArrayList<TShirt> matchingTShirts = new ArrayList<TShirt>();
		try {
			allTShirts = getAllTshirts("Nike.csv");
			allTShirts.addAll(getAllTshirts("Adidas.csv"));
			allTShirts.addAll(getAllTshirts("Puma.csv"));
			
			} catch (IOException e) {
			e.printStackTrace();
		}
		for (TShirt tShirt : allTShirts) {
			if (tShirt.getGender().equals(tShirtSearchDTO.getGender())
					&& tShirt.getColour().equals(tShirtSearchDTO.getColor())
					&& tShirt.getSize().equals(tShirtSearchDTO.getSize())) {
				matchingTShirts.add(tShirt);
             }
		}

		return matchingTShirts;

	}

	public void compare(int ch) {
		Output output = new Output();
		if (ch == 1) {
			Collections.sort(getMatchingTshirts(null), new Comparator<TShirt>() {
				public int compare(TShirt o1, TShirt o2) {
					return (int) (o1.getPrice());
				}
			});

		} else if (ch == 2) {
			Collections.sort(getMatchingTshirts(null), new Comparator<TShirt>() {
				public int compare(TShirt o1, TShirt o2) {
					return (int) (o2.getRating());
				}
			});
		} else {
			System.out.println("WrongChoice");
			return;
		}
		output.displayDetails(getMatchingTshirts(null));

	}

	private ArrayList<TShirt> getAllTshirts(final String fileName) throws IOException {

		final ClassLoader classLoader = getClass().getClassLoader();
		final InputStream inputStream = classLoader.getResourceAsStream(fileName);
		final InputStreamReader streamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
		final BufferedReader reader = new BufferedReader(streamReader);

		final ArrayList<TShirt> tshirts = new ArrayList<TShirt>();

		final Iterable<CSVRecord> records = CSVFormat.DEFAULT.withHeader().withDelimiter('|').parse(reader);
		for (CSVRecord record : records) {
			final TShirt tshirt = new TShirt();
			tshirt.setiD(record.get("ID"));
			tshirt.setName(record.get("NAME"));
			tshirt.setColour(record.get("COLOUR"));
			tshirt.setGender(record.get("GENDER_RECOMMENDATION"));
			tshirt.setSize(record.get("SIZE"));
			tshirt.setPrice(Double.parseDouble(record.get("PRICE")));
			tshirt.setRating(Double.parseDouble(record.get("RATING")));
			tshirt.setAvailability(record.get("AVAILABILITY"));
			
			
			tshirts.add(tshirt);
		}

		return tshirts;

	}
}
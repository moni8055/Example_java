package com.nagarro.training.csv_assignment.view;

import java.util.Scanner;

//import com.nagarro.training.csv_assignment.domain.TShirt;
import com.nagarro.training.csv_assignment.dto.TShirtSearchDTO;

public class Input {
	public TShirtSearchDTO getDetails() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Color");
		String color = sc.nextLine();
		
		System.out.println("Enter the Size");
		String size = sc.nextLine();
		
		System.out.println("Enter the Gender");
		String gender = sc.nextLine();

		System.out.println("Enter output preference");
		String outputpreference = sc.nextLine();

		TShirtSearchDTO tShirtDTO = new TShirtSearchDTO();
		tShirtDTO.setColor(color);
		tShirtDTO.setSize(size);
		tShirtDTO.setGender(gender);
		tShirtDTO.setOutputPreference(outputpreference);

		return tShirtDTO;

	}

}

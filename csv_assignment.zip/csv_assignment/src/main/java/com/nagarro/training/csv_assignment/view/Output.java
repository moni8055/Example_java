package com.nagarro.training.csv_assignment.view;

import java.util.ArrayList;
import java.util.Arrays;

import com.nagarro.training.csv_assignment.domain.*;

public class Output {
	public void displayDetails(ArrayList<TShirt> tShirts) {
		System.out.println("\n \t \t Tshirt information");
		System.out.println("ID|Name|Color|Gender|Size|Price|Rating|Availability");
		
		for(TShirt T : tShirts) {
			System.out.print("|" + T.getiD());
			System.out.print("|" + T.getName());
			System.out.print("|" + T.getColour());
			System.out.print("|" + T.getGender());
			System.out.print("|" + T.getSize());
			System.out.print("|" + T.getPrice());
			System.out.print("|" + T.getRating());
			System.out.println("|" + T.getAvailability());
		}
		if(tShirts.isEmpty()) {
			System.out.println("Tshirt is not available");
		}
		
}

}
